var casper = require('casper').create();
var baz = require('baz');
console.log(baz);
casper.exit();
